00:00 Inicio
01:30 Punto Uno
07:00 Algo Importante
